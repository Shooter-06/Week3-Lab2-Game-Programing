using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetComp : MonoBehaviour
{
    public GameObject target;
    private int score;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter(Collision collision){
        // Debug.Log("Hit1");
        if(collision.gameObject.tag == "Projectile"){
            Destroy(collision.gameObject);
            Hide();
        }
            
    }

    void Hide(){
        target.SetActive(false);
        Debug.Log("Hit");
        Invoke("respawn", 5);
    }

    void respawn(){
        target.SetActive(true);
    }
}
