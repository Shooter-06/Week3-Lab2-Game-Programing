namespace Unity.Cloud.Collaborate.Presenters
{
    internal interface IStartPresenter : IPresenter
    {
        void RequestStart();
    }
}
