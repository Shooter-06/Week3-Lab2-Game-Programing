# Getting started with Plastic SCM for Unity

Plastic SCM for Unity will allow you to use Plastic SCM directly in Unity and is available via the Version Control package in the Unity Package Manager.

Learn more about [Plastic SCM Cloud Edition](https://unity.com/products/plastic-scm).

* To start with a new Plastic SCM repository for your project, see [Getting started with a New Plastic SCM repository](NewPlasticRepo.md).
* To start from an existing Plastic SCM repository, see [Getting started with an existing Plastic SCM repository](ExistingPlasticRepo.md).